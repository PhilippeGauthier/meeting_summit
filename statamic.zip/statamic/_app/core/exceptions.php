<?php

class ResourceNotFoundException extends Exception {}

class FatalException extends Exception {}