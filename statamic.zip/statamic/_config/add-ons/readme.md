
Add-on Config
==========================

Add-on specific settings get to live in this folder. It's kinda cozy.